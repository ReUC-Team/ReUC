
import json
import re
import csv

# Read the file content
with open('json.txt', 'r', encoding='utf-8') as f:
    content = f.read()

# Extract the JSON data from the Google Visualization format
json_match = re.search(r'google\.visualization\.Query\.setResponse\((.*)\);', content, re.DOTALL)
if json_match:
    json_str = json_match.group(1)
    data = json.loads(json_str)
    
    # Extract the table structure
    cols = data['table']['cols']
    rows = data['table']['rows']
    
    # Keywords related to systems, software, IT
    keywords = [
        'sistema', 'software', 'informática', 'informatica', 'computación', 'computacion',
        'tecnología', 'tecnologia', 'programación', 'programacion', 'desarrollo',
        'ti', 't.i.', 'ciberseguridad', 'redes', 'digital', 'web', 'app', 'tecnológico',
        'tecnologico', 'datos', 'base de datos', 'telecomunicaciones'
    ]
    
    # List to store all vacancies related to systems/software
    sistemas_vacantes = []
    
    # Process each row
    for row in rows:
        cells = row['c']
        # Get the company name (column B, index 1)
        if cells[1] and 'v' in cells[1]:
            company_name = cells[1]['v']
            company_name_lower = company_name.lower()
            
            # Check if any keyword is in the company name
            if any(keyword in company_name_lower for keyword in keywords):
                vacancy_info = {
                    'ÁMBITO': cells[0]['v'] if cells[0] and 'v' in cells[0] else '',
                    'NOMBRE DE LA UNIDAD RECEPTORA': company_name,
                    'MODALIDAD': cells[2]['v'] if cells[2] and 'v' in cells[2] else '',
                    'LUGAR': cells[3]['v'] if cells[3] and 'v' in cells[3] else '',
                    'FECHA': cells[4]['v'] if cells[4] and 'v' in cells[4] else '',
                    'TIPO': cells[5]['v'] if cells[5] and 'v' in cells[5] else '',
                    'SECTOR': cells[6]['v'] if cells[6] and 'v' in cells[6] else '',
                    'NOMBRE DEL RESPONSABLE': cells[7]['v'] if cells[7] and 'v' in cells[7] else '',
                    'TELÉFONO': cells[8]['v'] if cells[8] and 'v' in cells[8] else '',
                    'CORREO': cells[9]['v'] if cells[9] and 'v' in cells[9] else '',
                    'SITIO WEB': cells[10]['v'] if cells[10] and 'v' in cells[10] else '',
                    'HORARIO ATENCIÓN': cells[11]['v'] if cells[11] and 'v' in cells[11] else '',
                    'CUPO DISPONIBLE': cells[12]['v'] if cells[12] and 'v' in cells[12] else ''
                }
                sistemas_vacantes.append(vacancy_info)
    
    # Save to CSV
    csv_filename = 'vacantes_sistemas_software.csv'
    with open(csv_filename, 'w', newline='', encoding='utf-8-sig') as csvfile:
        if sistemas_vacantes:
            fieldnames = sistemas_vacantes[0].keys()
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(sistemas_vacantes)
    
    # Also save to TXT with formatted output
    txt_filename = 'vacantes_sistemas_software.txt'
    with open(txt_filename, 'w', encoding='utf-8') as txtfile:
        txtfile.write("="*100 + "\n")
        txtfile.write("VACANTES DEL ÁREA DE SISTEMAS, SOFTWARE Y TECNOLOGÍA\n")
        txtfile.write(f"Total de vacantes encontradas: {len(sistemas_vacantes)}\n")
        txtfile.write("="*100 + "\n\n")
        
        for i, vacancy in enumerate(sistemas_vacantes, 1):
            txtfile.write(f"{i}. {vacancy['NOMBRE DE LA UNIDAD RECEPTORA']}\n")
            txtfile.write(f"   Ámbito: {vacancy['ÁMBITO']}\n")
            txtfile.write(f"   Modalidad: {vacancy['MODALIDAD']}\n")
            txtfile.write(f"   Lugar: {vacancy['LUGAR']}\n")
            txtfile.write(f"   Tipo: {vacancy['TIPO']}\n")
            txtfile.write(f"   Sector: {vacancy['SECTOR']}\n")
            if vacancy['NOMBRE DEL RESPONSABLE']:
                txtfile.write(f"   Responsable: {vacancy['NOMBRE DEL RESPONSABLE']}\n")
            if vacancy['TELÉFONO']:
                txtfile.write(f"   Teléfono: {vacancy['TELÉFONO']}\n")
            if vacancy['CORREO']:
                txtfile.write(f"   Correo: {vacancy['CORREO']}\n")
            if vacancy['SITIO WEB']:
                txtfile.write(f"   Sitio Web: {vacancy['SITIO WEB']}\n")
            if vacancy['HORARIO ATENCIÓN']:
                txtfile.write(f"   Horario: {vacancy['HORARIO ATENCIÓN']}\n")
            if vacancy['CUPO DISPONIBLE']:
                txtfile.write(f"   Cupo Disponible: {vacancy['CUPO DISPONIBLE']}\n")
            txtfile.write("-"*100 + "\n\n")
    
    print(f"Total de vacantes encontradas: {len(sistemas_vacantes)}")
    print(f"\nArchivos generados:")
    print(f"1. {csv_filename} (formato CSV para Excel)")
    print(f"2. {txt_filename} (formato texto)")
    print(f"\nLos archivos están listos para descargar.")
